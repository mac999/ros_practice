#pragma once

void parsingIMU(std::string value, float& roll, float& pitch, float& yaw);
