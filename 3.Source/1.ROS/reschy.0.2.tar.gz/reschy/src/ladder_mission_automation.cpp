// point cloud unit is meter.

void moveFoward(bool leftSide, float leftDistance, bool rightSide, float rightDistance)
{
	const float wheelRadius = 0.10;

	float leftSpeed = leftDistance / wheelRadius;
	float rightSpeed = rightDistance / wheelRadius;
	moveFoward(leftSide, rightSide, leftSpeed, 1000.0, rightSpeed, 1000.0);
}

void moveForward(bool leftSide, float leftSpeed, float leftMilliSecond, bool rightSide, float rightSpeed, float rightMilliSecond)
{
	// publishMessage(...); // considering left and right side wheel.
}

bool FindStairAndMoveToFront()
{
	bool bFind = false;
	bool bRet = true;

	int maxCount = 60 * 2;	// 60 seconds * 2 = 2 minutes
	for(int tryCount = 0; tryCount < maxCount; tryCount++)
	{
		const float nearStairDistance = 0.5;
		const float farStairDistance = 1.5;
		int SegmentId = findStair(nearStairDistance, farStairDistance);
		moveForward(true, 0.2, true, 0.2);
		if(SegmentId >= 0)	// found stair segment under condition.
			break;
	}
	return bFind;
}

struct Rect3D
{
	pcl::PointXYZ pt1, pt2;
};

pcl::PointCloud<pcl::PointXYZI> _CurrentPointCloudSegments;
pcl::PointCloud<pcl::PointXYZI> _CurrentSegmentsAABB;	// Axis-aligned bounding box about each segments

void subscribePointCloudSegments(const sensor_msg::PointCloud2ConstPtr& input)
{
	_CurrentPointCloudSegments.clear();
	pcl::fromROSMsg(*input, _CurrentPointCloudSegments);
}

void subscribeSegmentsAABB(const sensor_msg::PointCloud2ConstPtr& input)
{
	_CurrentSegmentsAABB.clear();
	pcl::fromROSMsg(*input, _CurrentSegmentsAABB);
}

int findStair(float nearStairDistance, float farStairDistance, float height = 0.5, float width = 0.3, float depth, float tolerance = 0.1)
{
	std::vector<pcl::PointIndices> clusterSegmentsIndices;
	getPointCloudCluster(_CurrentPointCloudSegments, clusterSegmentsIndices);

	std::vector<pcl::PointIndices> clusterAABBIndices;
	getPointCloudCluster(_CurrentPointCloudSegments, clusterAABBIndices);
	
	int SegmentId = -1;
	for(std::vector<int>::const_iterator it = clusterAABBIndices.begin(); it != clusterAABBIndices.end(); ++it)
	{
		pcl::PointCloud<pcl::PointXYZI> pointsAABB;
		getPointCloud(clusterAABBIndices, it->indices, pointsAABB);

		Rect3D MaxRect;	
		if(getMaximumRect(pointsAABB, MaxRect) == false)
			continue;

		if(MaxRect.pt2.z < nearStairDistance - tolerance)
			continue;
		if(MaxRect.pt1.z > farStairDistance + tolerance)
			continue;

		getVolume(pointsAABB, segmentHeight, segmentWidth, segmentDepth);
		if(IsEqual(segmentHeight, height, tolerance) && 
			IsEqual(segmentWidth, width, tolerance) && 
			IsEqual(segmentDepth, depth, tolerance))
		{ 
			SegmentId = pointsAABB[0].intensity;
			return SegmentId;
		}
	}
	return SegmentId;
}

bool seeFrontDoor()
{
}

bool seeFrontDoor()
{
	// About each segments, detect door which has features such as door volume, distance etc.
}

bool touchStairTop()
{
	bool bSeeFrontDoor = seeFrontDoor();
	if(bSeeFrontDoor)
		return true;
	return false;	
}

bool moveToStairTop()	
{
	// Consideration:
	//		If there is unbalancing issue related to left and right side friction,
	//		our robot will be down. 
	//			
	bool bTouchStairTop = false;	
	int maxCount = 60 * 2; 	// 60 seconds * 2 = 2 minutes
	for(int tryCount = 0; tryCount < maxCount; tryCount++)
	{
		moveForward(true, 0.2, true, 0.2);
		bTouchStairTop = TouchStairTop();
		if(bTouchStairTop)
			break;
	}
	if(bTouchStairTop == false)
		return false;
		
	moveForward(true, 0.4, true, 0.4);
	return true;
}

void main()
{
	bool bFindStair = FindStairAndMoveToFront();
	if(bFindStair == false)
	{
		cout << "Fail FindStair step!");
		return;
	}
	
	bool bSuccess = moveToStairTop();		
	if(bSuccess)
		cout << "Success Stair stage!");	
}
