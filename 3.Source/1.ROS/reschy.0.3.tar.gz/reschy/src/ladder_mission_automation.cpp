// package: reschy
// module: root_sensor_RGBD
// revision history
// date       | author      | description
// 2015.10.1  | T.W. Kang   | draft version for autonomous operation related to ladder mission.
// 
//
//
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/JointState.h>
// PCL specific includes
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/ros/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>

// subscriber
bool _subSegments = false;	// subscribed data sync flag
bool _subAABB = false;

pcl::PointCloud<pcl::PointXYZI> _CurrentPointCloudSegments;
pcl::PointCloud<pcl::PointXYZI> _CurrentSegmentsAABB;	// Axis-aligned bounding box about each segments

void subscribeSegments(const sensor_msg::PointCloud2ConstPtr& input)
{
	_CurrentPointCloudSegments.clear();
	pcl::fromROSMsg(*input, _CurrentPointCloudSegments);
	_subSegments = true;
}

void subscribeAABB(const sensor_msg::PointCloud2ConstPtr& input)
{
	_CurrentSegmentsAABB.clear();
	pcl::fromROSMsg(*input, _CurrentSegmentsAABB);
	_subAABB = true;
}

// node functions
void moveFoward(float leftDistance, float rightDistance)
{
	const float wheelRadius = 0.10;

	float leftSpeed = leftDistance / wheelRadius;
	float rightSpeed = rightDistance / wheelRadius;
	moveFoward(leftSpeed, 1000.0, rightSpeed, 1000.0);
}

void moveForward(float leftSpeed, float leftMilliSecond, float rightSpeed, float rightMilliSecond)
{
	// publishMessage(...); // considering left and right side wheel.
}

struct Rect3D
{
	pcl::PointXYZ pt1, pt2;
};

int canSeeLadder(float nearLadderDistance, float farLadderDistance, float height = 0.5, float width = 0.3, float depth, float tolerance = 0.1)
{
	std::vector<pcl::PointIndices> clusterSegmentsIndices;
	getPointCloudCluster(_CurrentPointCloudSegments, clusterSegmentsIndices);

	std::vector<pcl::PointIndices> clusterAABBIndices;
	getPointCloudCluster(_CurrentPointCloudSegments, clusterAABBIndices);
	
	int SegmentId = -1;
	for(std::vector<int>::const_iterator it = clusterAABBIndices.begin(); it != clusterAABBIndices.end(); ++it)
	{
		pcl::PointCloud<pcl::PointXYZI> pointsAABB;
		getPointCloud(clusterAABBIndices, it->indices, pointsAABB);

		Rect3D MaxRect;	
		if(getMaximumRect(pointsAABB, MaxRect) == false)
			continue;

		if(MaxRect.pt2.z < nearLadderDistance - tolerance)
			continue;
		if(MaxRect.pt1.z > farLadderDistance + tolerance)
			continue;

		getVolume(pointsAABB, segmentHeight, segmentWidth, segmentDepth);
		if(IsEqual(segmentHeight, height, tolerance) && 
			IsEqual(segmentWidth, width, tolerance) && 
			IsEqual(segmentDepth, depth, tolerance))
		{ 
			SegmentId = pointsAABB[0].intensity;
			return SegmentId;
		}
	}
	return SegmentId;
}

bool canSeeFrontDoor()
{
	// About each segments, detect door which has features such as door volume, distance etc.
}

bool canSeeLadderTop()
{
	bool canSeeFrontDoor = canSeeFrontDoor();
	return canSeeFrontDoor;
}

enum RobotActionStep
{
	Stop = 0, 
	Finish = 1, 
	Run = 2, 
	Climb = 3,
} _stepStatus = RobotActionStep::Stop;

void 
subscribeActive(const sensor_msgs::JointStatePtr& state)
{
	if(strcmpi(state.name[0], "on") == 0)
		_stepStatus = RobotActionStep::Run;
	else if(strcmpi(state.name[0], "off") == 0)
		_stepStatus = RobotActionStep::Stop;
}

void 
subscribeRunLadder(const sensor_msgs::JointStatePtr& state)
{
	if(_stepStatus <= RobotActionStep::Finish)
		return;
	if(_subSegments == false || _subAABB == false)
		return;
	_subSegments = false;	// subscribed data sync flag
	_subAABB = false;

	if(_stepStatus == RobotActionStep::Run)
	{
		const float nearLadderDistance = 0.5;
		const float farLadderDistance = 1.5;
		int SegmentId = canSeeLadder(nearLadderDistance, farLadderDistance);
		if(SegmentId < 0)	// didn't find Ladder segment under condition.
		{
			moveForward(0.2, 0.2);
			return;
		}
		else		// found it
			_stepStatus = RobotActionStep::Climb;
	}
	else if(_stepStatus == RobotActionStep::Climb)
	{
		bool bcanSeeLadderTop = canSeeLadderTop()
		if(bcanSeeLadderTop == false)
		{
			moveForward(0.2, 0.2);
			return;
		}
		moveForward(0.4, 0.4);

		sensor_msgs::JointState state;  
		strcpy(state.name[0], "finish"); 
		pub_obj.publish(state); 
	}
}

ros::Publisher pubStatus;

int
main (int argc, char** argv)
{
	// Initialize ROS
	ros::init (argc, argv, "ladder_mission_automation");
	ros::NodeHandle nh;

	ros::Subscriber subSegments = nh.subscribe ("reschy/control/active/ladder", 1, subscribeActive);
	ros::Subscriber subSegments = nh.subscribe ("reschy/sensor/segments", 1, subscribeSegments);
	ros::Subscriber subAABB = nh.subscribe ("reschy/sensor/AABB", 1, subscribeAABB);
	
	// By using timer, robot_master_controller node should send control/run message for autonomous operation
  	ros::Subscriber subSegments = nh.subscribe ("reschy/control/run/ladder", 1, subscribeRun);	

  	pubStatus = nh.advertise<sensor_msgs::JointState> ("reschy/status/run/ladder", 1);	// ex) ladder=finish, ladder=run, ladder=fail

	// Spin
	ros::spin();	// Call event functions (subscribers)
}
