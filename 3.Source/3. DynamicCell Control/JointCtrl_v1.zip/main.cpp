/*
 * main.cpp
 *
 *  Created on: 2013. 1. 3.
 *      Author: zerom
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <string.h>
#include <termios.h>
#include "dynamixel.h"

using namespace DXL_PRO;

//Dynamixel DXL("/dev/ttyUSB0");
Dynamixel DXL("/dev/ttyAMA0");

int _getch()
{
    struct termios oldt, newt;
    int ch;
    tcgetattr( STDIN_FILENO, &oldt );
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr( STDIN_FILENO, TCSANOW, &newt );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
    return ch;
}

int kbhit(void)
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if(ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}


// Control table address
#define P_TORQUE_ENABLE         24
#define P_GOAL_POSITION_LL      30
#define P_PRESENT_POSITION_LL   36
#define P_MOVING                46
#define JOINT_NUM		4

// Defulat setting
//#define DEFAULT_ID              1
#define DEFAULT_BAUDNUM         2 // 115,200

void PrintCommStatus(int CommStatus);
void PrintErrorCode(int ErrorCode);

int main(int argc, char* argv[])
{
	//joint to DXL id
	int joint2cell[JOINT_NUM]={1,7,9,10};

	//input Parameters
	int joint_id=atoi(argv[1]);
	double deg=atof(argv[2]);
	if(deg<0)deg=0;
	if(deg>360)deg=360;
	int pos = deg*11.3;//deg to pos

    	int PresentPos = 0;
	int PresentPos2 = 0;
    	int result = COMM_TXFAIL, error = 0, Moving = 1;
	int result2 = COMM_TXFAIL;
	int* PosRange[JOINT_NUM];
	for(int i=0; i<JOINT_NUM; i++)
		PosRange[i]=new int [2];

    	//PosRange[joint_id] = {min, max};// 0~4095
	int margin =100;
	PosRange[0][0]=0+margin;
	PosRange[0][1]=3200-margin;
	PosRange[1][0]=1686+margin;
	PosRange[1][1]=3828-margin;
	PosRange[2][0]=1024+margin;
	PosRange[2][1]=3076-margin;
	PosRange[3][0]=1032+margin;
	PosRange[3][1]=4090-margin;

	//check PosRange
	if(pos<PosRange[joint_id][0])pos=PosRange[joint_id][0];
	if(pos>PosRange[joint_id][1])pos=PosRange[joint_id][1];

	//opposite pos for  joint1, cell id 7,8
	int op_pos=2048+(2048-pos);



    Dynamixel DXL("/dev/ttyAMA0");

    // Open device
    if( DXL.Connect() == 0 )
    {
        printf( "Failed to open USB2Dynamixel!\n" );
        printf( "Press any key to terminate...\n" );
        _getch();
        return 0;
    }
    else
        printf( "Succeed to open USB2Dynamixel!\n" );

    if(DXL.SetBaudrate(DEFAULT_BAUDNUM) == true)
    {
    	printf( "Succeed to change the baudrate!\n" );
    }
    else
    {
        printf( "Failed to change the baudrate!\n" );
        printf( "Press any key to terminate...\n" );
        _getch();
        return 0;
    }

    result = DXL.WriteByte(joint2cell[joint_id], P_TORQUE_ENABLE, 1, &error);

    if(result == COMM_RXSUCCESS)
    {
		PrintErrorCode(error);
    }
    else
    	PrintCommStatus(result);




/////////////////////////////////////////////////////JOINT CONTROL//////////////////////////////////////////////////////

		
	// Write goal position
	//DXL.WriteWord( DEFAULT_ID, P_GOAL_POSITION_LL, GoalPos[index], &error);

	if(joint_id==0)//id#6
	{
		DXL.WriteWord( joint2cell[joint_id], P_GOAL_POSITION_LL, pos, &error);
	}
	else if(joint_id==1)//id#7,8
	{
		DXL.WriteWord(7, P_GOAL_POSITION_LL, pos, &error);
		DXL.WriteWord(8, P_GOAL_POSITION_LL, op_pos, &error);//반대방향
	}
	else if(joint_id==2)//id#9
	{
		DXL.WriteWord( joint2cell[joint_id], P_GOAL_POSITION_LL, pos, &error);
	}
	else if(joint_id==3)//id#10
	{
		DXL.WriteWord( joint2cell[joint_id], P_GOAL_POSITION_LL, pos, &error);
	}
	else
	{
	}
	


	do
	{
		// Check moving done
		result = DXL.ReadByte(  joint2cell[joint_id], P_MOVING, &Moving, &error);

		//check pos
		//result = DXL.ReadWord(  joint2cell[joint_id], P_PRESENT_POSITION_LL, (int*) &PresentPos, &error);
		//printf( "DXL_id=%d,  current=%d\n", joint2cell[joint_id] , PresentPos );
		//result2 = DXL.ReadWord(  8, P_PRESENT_POSITION_LL, (int*) &PresentPos2, &error);
		//printf( "DXL_id=%d,  current=%d\n", 8 , PresentPos2 );

	}while(Moving == 1);



	// Read present position
	result = DXL.ReadWord(  joint2cell[joint_id], P_PRESENT_POSITION_LL, (int*) &PresentPos, &error);
	result2 = DXL.ReadWord( 8, P_PRESENT_POSITION_LL, (int*) &PresentPos2, &error);
	if( result == COMM_RXSUCCESS )
	{
		printf( "from%dto%d,  current=%d\n", PosRange[joint_id][0], PosRange[joint_id][1], PresentPos );
		//printf( "from%dto%d,  current=%d\n", PosRange[joint_id][0], PosRange[joint_id][1], PresentPos2 );
		PrintErrorCode(error);
	}
	else
	{
		PrintCommStatus(result);
	}
		
	

	// Close device
	DXL.Disconnect();
	printf( "End to terminate...\n" );
	//_getch();
	return 0;
}

// Print communication result
void PrintCommStatus(int CommStatus)
{
    switch(CommStatus)
    {
    case COMM_TXFAIL:
        printf("COMM_TXFAIL: Failed transmit instruction packet!\n");
        break;

    case COMM_TXERROR:
        printf("COMM_TXERROR: Incorrect instruction packet!\n");
        break;

    case COMM_RXFAIL:
        printf("COMM_RXFAIL: Failed get status packet from device!\n");
        break;

    case COMM_RXWAITING:
        printf("COMM_RXWAITING: Now recieving status packet!\n");
        break;

    case COMM_RXTIMEOUT:
        printf("COMM_RXTIMEOUT: There is no status packet!\n");
        break;

    case COMM_RXCORRUPT:
        printf("COMM_RXCORRUPT: Incorrect status packet!\n");
        break;

    default:
        printf("This is unknown error code!\n");
        break;
    }
}

// Print error bit of status packet
void PrintErrorCode(int ErrorCode)
{
    if(ErrorCode & ERRBIT_VOLTAGE)
        printf("Input voltage error!\n");

    if(ErrorCode & ERRBIT_ANGLE)
        printf("Angle limit error!\n");

    if(ErrorCode & ERRBIT_OVERHEAT)
        printf("Overheat error!\n");

    if(ErrorCode & ERRBIT_RANGE)
        printf("Out of range error!\n");

    if(ErrorCode & ERRBIT_CHECKSUM)
        printf("Checksum error!\n");

    if(ErrorCode & ERRBIT_OVERLOAD)
        printf("Overload error!\n");

    if(ErrorCode & ERRBIT_INSTRUCTION)
        printf("Instruction code error!\n");
}


