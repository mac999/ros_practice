bool func_InitIMG();
bool func_CalcIMG__ER(int &x1, int &y1, int &x2, int &y2);
bool waitKey();
