/////////////////////////////////////////////////////
// A Simple Line Tracking Framework for Two Wheel ver.1.0
// LEON
/////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// MOTION ///////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <iostream>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <string.h>
#include <termios.h>
#include "dynamixel.h"
#include "motion.h"

// Control table address
#define CT_CW_ANGLE_LIMIT			6
#define CT_CCW_ANGLE_LIMIT			8
#define CT_TORQUE_ENABLE        		24
#define CT_GOAL_POSITION			30
#define CT_MOVING_SPEED			32
#define CT_PRESENT_SPEED  			38
#define CT_MOVING               			46

// Value 
#define VAL_ID_LEFT_UP_WHEEL              4
#define VAL_ID_LEFT_DOWN_WHEEL        2
#define VAL_ID_RIGHT_UP_WHEEL            3
#define VAL_ID_RIGHT_DOWN_WHEEL     1
//#define VAL_ID_LINER_WHEEL			5
//#define VAL_ID_HEAD_JOINT              	6
#define VAL_BAUDNUM         			2
#define PKT_RTN_DELAY_US			5000


using namespace std;
using namespace DXL_PRO;

int vL=0, vR=0;
int error = 0, Moving = 1;

Dynamixel DXL("/dev/ttyAMA0"); // Port Name Setting

int funcMOT_InitUART()
{
	if (DXL.Connect() == 0)	// Serial Port Connection
	{
		printf("Failed to open the PORT\n");
		return 0;
	}
	else
		printf("Succeed to open the PORT\n");

	if (DXL.SetBaudrate(VAL_BAUDNUM) == true)	// Baudrate Setting
	{
		printf("Succeed to change the baudrate!\n");
	}
	else
	{
		printf("Failed to change the baudrate!\n");
		return 0;
	}
	
	return 1;
}
 
void funcMOT_CloseUART()
{
		DXL.Disconnect();	// Close PORT
	}

void funcMOT_InitializeDXL()
{
	funcMOT_InitDXLMode();	// Wheel Mode, Joint Mode

	funcMOT_InitDXLTorque();	// Torque : ON

	funcMOT_InitDXLMove();	// speed : 0 (stop)
}

void funcMOT_InitDXLMode()
{
	// LEFT DXL MODE INITIALIZE :: WHEEL
	DXL.WriteWord(VAL_ID_LEFT_UP_WHEEL, CT_CW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_LEFT_UP_WHEEL, CT_CCW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	DXL.WriteWord(VAL_ID_LEFT_DOWN_WHEEL, CT_CW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_LEFT_DOWN_WHEEL, CT_CCW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	// RIGHT DXL MODE INITIALIZE :: WHEEL
	DXL.WriteWord(VAL_ID_RIGHT_UP_WHEEL, CT_CW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_RIGHT_UP_WHEEL, CT_CCW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	DXL.WriteWord(VAL_ID_RIGHT_DOWN_WHEEL, CT_CW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_RIGHT_DOWN_WHEEL, CT_CCW_ANGLE_LIMIT, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	// HEAD DXL MODE INITIALIZE :: JOINT
//	DXL.WriteWord(VAL_ID_HEAD_JOINT , CT_CW_ANGLE_LIMIT, 0, 0);
//	usleep(PKT_RTN_DELAY_US);
//	DXL.WriteWord(VAL_ID_HEAD_JOINT , CT_CCW_ANGLE_LIMIT, 4095, 0);
//	usleep(PKT_RTN_DELAY_US);
}

void funcMOT_InitDXLTorque()
{
	// LEFT WHEEL TORQUE INITIALIZE :: ON
	DXL.WriteByte(VAL_ID_LEFT_UP_WHEEL, CT_TORQUE_ENABLE, 1, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteByte(VAL_ID_LEFT_DOWN_WHEEL, CT_TORQUE_ENABLE, 1, 0);
	usleep(PKT_RTN_DELAY_US);

	// RIGHT WHEEL TORQUE INITIALIZE :: ON
	DXL.WriteByte(VAL_ID_RIGHT_UP_WHEEL, CT_TORQUE_ENABLE, 1, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteByte(VAL_ID_RIGHT_DOWN_WHEEL, CT_TORQUE_ENABLE, 1, 0);
	usleep(PKT_RTN_DELAY_US);

	// HEAD JOINT TORQUE INITIALIZE :: ON
//	DXL.WriteByte(VAL_ID_HEAD_JOINT , CT_TORQUE_ENABLE, 1, 0);
//	usleep(PKT_RTN_DELAY_US);
}

void funcMOT_DisposeDXLTorque()
{
	// LEFT WHEEL TORQUE INITIALIZE :: OFF
	DXL.WriteByte(VAL_ID_LEFT_UP_WHEEL, CT_TORQUE_ENABLE, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteByte(VAL_ID_LEFT_DOWN_WHEEL, CT_TORQUE_ENABLE, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	// RIGHT WHEEL TORQUE INITIALIZE :: OFF
	DXL.WriteByte(VAL_ID_RIGHT_UP_WHEEL, CT_TORQUE_ENABLE, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteByte(VAL_ID_RIGHT_DOWN_WHEEL, CT_TORQUE_ENABLE, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	// HEAD JOINT TORQUE INITIALIZE :: OFF
//	DXL.WriteByte(VAL_ID_HEAD_JOINT , CT_TORQUE_ENABLE, 0, 0);
//	usleep(PKT_RTN_DELAY_US);
}

void funcMOT_InitDXLMove()
{
	// LEFT WHEEL MOVE INITIALIZE :: STOP
	DXL.WriteWord(VAL_ID_LEFT_UP_WHEEL, CT_MOVING_SPEED, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_LEFT_DOWN_WHEEL, CT_MOVING_SPEED, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	// RIGHT WHEEL MOVE INITIALIZE :: STOP
	DXL.WriteWord(VAL_ID_RIGHT_UP_WHEEL, CT_MOVING_SPEED, 0, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_RIGHT_DOWN_WHEEL, CT_MOVING_SPEED, 0, 0);
	usleep(PKT_RTN_DELAY_US);

	// HEAD JOINT INITIALIZE :: CENTER
//	DXL.WriteByte(VAL_ID_HEAD_JOINT , CT_GOAL_POSITION, 0, 0);
//	usleep(PKT_RTN_DELAY_US);
}

void funcMOT_MoveDXL()
{
	int resultLU = COMM_TXFAIL, resultLD = COMM_TXFAIL, resultRU = COMM_TXFAIL, resultRD = COMM_TXFAIL;
	int PresentSpdLU = 0, PresentSpdLD = 0, PresentSpdRU = 0, PresentSpdRD = 0;
	
	// Write LEFT WHEEL SPEED :: vL
	DXL.WriteWord(VAL_ID_LEFT_UP_WHEEL, CT_MOVING_SPEED, vL, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_LEFT_DOWN_WHEEL, CT_MOVING_SPEED, vL, 0);
	usleep(PKT_RTN_DELAY_US);

	// Write RIGHT WHEEL SPEED :: vR
	DXL.WriteWord(VAL_ID_RIGHT_UP_WHEEL, CT_MOVING_SPEED, vR, 0);
	usleep(PKT_RTN_DELAY_US);
	DXL.WriteWord(VAL_ID_RIGHT_DOWN_WHEEL, CT_MOVING_SPEED, vR, 0);
	usleep(PKT_RTN_DELAY_US);

	// Read LEFT WHEEL PRESENT SPEED
	resultLU = DXL.ReadWord(VAL_ID_LEFT_UP_WHEEL , CT_PRESENT_SPEED , (int*) &PresentSpdLU, &error);
	usleep(PKT_RTN_DELAY_US);
	resultLD = DXL.ReadWord(VAL_ID_LEFT_DOWN_WHEEL , CT_PRESENT_SPEED , (int*) &PresentSpdLD, &error);
	usleep(PKT_RTN_DELAY_US);

	// Read RIGHT WHEEL PRESENT SPEED
	resultRU = DXL.ReadWord(VAL_ID_RIGHT_UP_WHEEL , CT_PRESENT_SPEED , (int*) &PresentSpdRU, &error);
	usleep(PKT_RTN_DELAY_US);
	resultRD = DXL.ReadWord(VAL_ID_RIGHT_DOWN_WHEEL , CT_PRESENT_SPEED , (int*) &PresentSpdRD, &error);
	usleep(PKT_RTN_DELAY_US);

	// Show the speed of the wheels
	if( (resultLU == COMM_RXSUCCESS && resultRU == COMM_RXSUCCESS) && 
		(resultLD == COMM_RXSUCCESS && resultRD == COMM_RXSUCCESS) )
	{
		printf( "vLU : %d \tvLD : %d \tvRU : %d\tvRD : %d\n", PresentSpdLU, PresentSpdLD,PresentSpdRU, PresentSpdRD);
	}
	else
	{
		printf( "vL or vR :: COMM_RXFAILED" );
	}

	usleep(100);
}

#define velocity_Offset			150 //100
#define P_GAIN					1   // 1	
#define P2						50 // 50
void funcMOT_CalcMotion(double &dL, double &dR)
{

	printf( "dL : %f  dR : %f\n", dL, dR);

	
	// using differential
	vL = dL*10.23;
	vR = dR*10.23;

	
	vR += 1024;

	// 0~1023 : CCW // 1024~2047 : CW
	// ex) LEFT WHEEL; CCW -> FORWARD, CW -> BACKWARD
	if(vL < 0)
		vL = 1024 - vL;
	else if(vL > 1023)
		vL = 1023;
	if(vR < 1024)
		vR = 1024 -vR;
	else if(vR > 2048)
		vR = 2048; 

	if(vL > vR - 1024)
		printf("[turning right] \n");
	else if(vL < vR - 1024)
		printf("[turning left] \n");
	else
		printf("[straight] \n");	
}

// Print communication result
void funcMOT_PrintCommStatus(int CommStatus)
{
	switch (CommStatus)
	{
	case COMM_TXFAIL:
		printf("COMM_TXFAIL: Failed transmit instruction packet!\n");
		break;

	case COMM_TXERROR:
		printf("COMM_TXERROR: Incorrect instruction packet!\n");
		break;

	case COMM_RXFAIL:
		printf("COMM_RXFAIL: Failed get status packet from device!\n");
		break;

	case COMM_RXWAITING:
		printf("COMM_RXWAITING: Now recieving status packet!\n");
		break;

	case COMM_RXTIMEOUT:
		printf("COMM_RXTIMEOUT: There is no status packet!\n");
		break;

	case COMM_RXCORRUPT:
		printf("COMM_RXCORRUPT: Incorrect status packet!\n");
		break;

	default:
		printf("This is unknown error code!\n");
		break;
	}
}

// Print error bit of status packet
void funcMOT_PrintErrorCode(int ErrorCode)
{
	if (ErrorCode & ERRBIT_VOLTAGE)
		printf("Input voltage error!\n");

	if (ErrorCode & ERRBIT_ANGLE)
		printf("Angle limit error!\n");

	if (ErrorCode & ERRBIT_OVERHEAT)
		printf("Overheat error!\n");

	if (ErrorCode & ERRBIT_RANGE)
		printf("Out of range error!\n");

	if (ErrorCode & ERRBIT_CHECKSUM)
		printf("Checksum error!\n");

	if (ErrorCode & ERRBIT_OVERLOAD)
		printf("Overload error!\n");

	if (ErrorCode & ERRBIT_INSTRUCTION)
		printf("Instruction code error!\n");
}
