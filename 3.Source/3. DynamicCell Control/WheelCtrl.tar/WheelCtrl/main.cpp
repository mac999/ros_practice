/////////////////////////////////////////////////////
// A Simple Line Tracking Framework for Two Wheel ver.1.0
// LEON
/////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include <iostream>
#include "motion.h"

using namespace std;

//LineTrace sp_L sp_R
//sp_L  범위 -100~100
//sp_R  범위 -100~100

int main(int argc, char* argv[])
{
	// Parameters
	//int x1 = 0, x2 = 0, y1 = 0, y2 = 0;

	int sp_L=atoi(argv[1]);
	int sp_R=atoi(argv[2]);


	//for(int i=0; i<argc ;i++)
	//{
        //	printf("input %d\n", sp_L);
	//}
	
	double dL=sp_L;
	double dR=sp_R;

	// Vision Setting
	//bool isCaptured = func_InitIMG();

	// Serial Port Initializing
	if (funcMOT_InitUART() == 0)
	{
		printf("ERROR : InitUART\n");
		return 0;
	}

	sleep(1);

	// DXL Initializing
	funcMOT_InitializeDXL();



	// Start
	while (1)
	{
		// Vision Processing
		//isCaptured = func_CalcIMG__ER(x1, y1, x2, y2);

		// Motion Calculating
		funcMOT_CalcMotion(dL, dR);

		// DXL Configurating
		funcMOT_MoveDXL();

		// Key Access to Abort
		char key = 0;
		key = getchar();
		if (key == 'q')
		{
			// Stop DXL
			funcMOT_InitDXLMove();

			// Close TORQUE OFF
		 	funcMOT_DisposeDXLTorque();
			
			// Close PORT
			funcMOT_CloseUART();
			break;
		}
	}

	return 0;
}



