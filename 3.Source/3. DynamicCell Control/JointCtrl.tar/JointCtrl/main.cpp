/////////////////////////////////////////////////////
// A Simple Line Tracking Framework for Two Wheel ver.1.0
// LEON
/////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include <iostream>
#include "motion.h"

using namespace std;

//JointCtrl 
int main(int argc, char* argv[])
{
	// Parameters
	//int x1 = 0, x2 = 0, y1 = 0, y2 = 0;

	//int sp_L=atoi(argv[1]);
	//int sp_R=atoi(argv[2]);


	int GoalPos = 125500; // 9-o-clock position for 54-series
    //int GoalPos = 75938; // 3-o-clock position for 42-series

	
	// Serial Port Initializing
	if (funcMOT_InitUART() == 0)
	{
		printf("ERROR : InitUART\n");
		return 0;
	}

	sleep(1);

	// DXL Initializing
	funcMOT_InitializeDXL();



	// Start
	while (1)
	{

		printf( "Press any key to continue (ESC to end program)\n" );
			if(getchar() == 0x1b){
			    break;
			}

		// DXL Configurating
		funcMOT_MoveDXL(GoalPos);

		// Key Access to Abort
		char key = 0;
		key = getchar();
		if (key == 'q')
		{
			// Stop DXL
			funcMOT_InitDXLMove();

			// Close TORQUE OFF
		 	funcMOT_DisposeDXLTorque();
			
			// Close PORT
			funcMOT_CloseUART();
			break;
		}
	}

	return 0;
}



