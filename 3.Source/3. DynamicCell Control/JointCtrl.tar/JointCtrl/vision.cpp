/////////////////////////////////////////////////////
// A Simple Line Tracking Framework for Two Wheel ver.1.0
// LEON
/////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////// VISION  ////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "vision.h"

using namespace cv;
using namespace std;

CvCapture* cvc_Captured;		// CvcImage::Input Image

IplImage *fr_Input			// IplImage::Input Image
		, *fr_Output			// IplImage::Line Detected Image
		, *fr_Middle;			// IplImage::Storage

Mat 	mClr_Input			// MatImage::Input Image
		, mClr_Contour		// MatImage::Contour Image
		, mClr_Middle;		// MatImage::Storage

int fr_Input__Width, fr_Input__Height;

void func_CalcIMG__MakeCenterPoint(IplImage *frame_IN, IplImage *frame_OUT, int &x1, int &y1, int &x2, int &y2);

bool func_InitIMG()
{
	// Camera Setting
	cvc_Captured = cvCaptureFromCAM(0);

	// Set Capture Size (default: 640 x 480)
	cvSetCaptureProperty(cvc_Captured, CV_CAP_PROP_FRAME_WIDTH, 320);
	cvSetCaptureProperty(cvc_Captured, CV_CAP_PROP_FRAME_HEIGHT, 240);

	// Get Frames from Captured Image
	fr_Input = cvQueryFrame(cvc_Captured);

	// fr_Input : get Width, Height
	fr_Input__Width = fr_Input->width;
	fr_Input__Height = fr_Input->height;

	// Set Window Size :: Input
	//cvNamedWindow("Input", 0);
	//cvResizeWindow("Input", fr_Input__Width, fr_Input__Height);

	// Set Window Size :: Output
	cvNamedWindow("Line Tracking", 0);
	cvResizeWindow("Line Tracking", fr_Input__Width, fr_Input__Height);

	// Make New Frame the Same Size of Input Frame
	fr_Output = cvCreateImage(cvGetSize(fr_Input), IPL_DEPTH_8U, 3);

	if (cvc_Captured != NULL)
		return 1;
	else
		return 0;
}

bool func_CalcIMG__ER(int &x1, int &y1, int &x2, int &y2) // Edge Recognition & Calculate Direction
{
	// Get Frames from Captured Image of the Camera
	fr_Input = cvQueryFrame(cvc_Captured);

	// Transfer :: Frame 2 Mat
	mClr_Input = cvarrToMat(fr_Input);

	// Filter :: Get Lines with Canny Algorithm
	Canny(mClr_Input, mClr_Contour, 100, 200);

	// Change Format
	cvtColor(mClr_Contour, mClr_Middle, CV_GRAY2BGR);

	// Storaging
	fr_Middle = new IplImage(mClr_Middle);

	// Filter :: Make Center Point
	func_CalcIMG__MakeCenterPoint(fr_Middle, fr_Output, x1, y1, x2, y2);

	// Show Image
	//cvShowImage("Input", fr_Input);
	cvShowImage("Line Tracking", fr_Output);

	if (cvc_Captured != NULL)
		return 1;
	else
		return 0;
}

int pre_x1 = 160, pre_x2 = 160; // storage of previous position from x1, x2 

void func_CalcIMG__MakeCenterPoint(IplImage *frame_IN, IplImage *frame_OUT, int &x1, int &y1, int &x2, int &y2)
{
	double interval = 30.0;

	int array_1[320];
	int array_2[320];
	int pos_X1 = 0;
	int pos_X2 = 0;
	int count_1 = 0;
	int count_2 = 0;

	int count_Clst1 = 0;
	int count_Clst2 = 0;

	int thres_PosY_1 = 190;
	int thres_PosY_2 = thres_PosY_1 - (int)(interval);

	bool isCountingClst1 = false;
	bool isCountingClst2 = false;

	for (int i = 0; i < fr_Input__Width; i++)
	{
		for (int j = 0; j < fr_Input__Height; j++)
		{
			frame_OUT->imageData[j * frame_OUT->widthStep + i * frame_OUT->nChannels + 2]
				= frame_IN->imageData[j * frame_IN->widthStep + i * frame_IN->nChannels + 2];
			frame_OUT->imageData[j * frame_OUT->widthStep + i * frame_OUT->nChannels + 1]
				= frame_IN->imageData[j * frame_IN->widthStep + i * frame_IN->nChannels + 1];
			frame_OUT->imageData[j * frame_OUT->widthStep + i * frame_OUT->nChannels + 0]
				= frame_IN->imageData[j * frame_IN->widthStep + i * frame_IN->nChannels + 0];
		}
	}

	for (int i = 0; i < fr_Input__Width; i++)
	{
		if (frame_IN->imageData[thres_PosY_1 * frame_IN->widthStep + i * frame_IN->nChannels + 2] != 0)
		{
			frame_OUT->imageData[thres_PosY_1 * frame_OUT->widthStep + i * frame_OUT->nChannels + 2] = 0xFF;

			array_1[i] = 1;
			if(!isCountingClst1)
			{
				count_Clst1 ++;
				isCountingClst1 = true;
			}
		}
		else
		{
			array_1[i] = 0;
			if(isCountingClst1)
			{
				isCountingClst1 = false;
			}
		}

		if (frame_IN->imageData[thres_PosY_2 * frame_IN->widthStep + i * frame_IN->nChannels + 2] != 0)
		{
			frame_OUT->imageData[thres_PosY_2 * frame_OUT->widthStep + i * frame_OUT->nChannels + 1] = 0xFF;

			array_2[i] = 1;
			if(!isCountingClst2)
			{
				count_Clst2 ++;
				isCountingClst2 = true;
			}		
		}
		else
		{
			array_2[i] = 0;
			if(isCountingClst2)
			{
				isCountingClst2 = false;
			}
		}
	}

	if(count_Clst1 > 1)
	{
		for (int i = 0; i < fr_Input__Width; i++)
		{
			if (array_1[i] != 0)
			{
				pos_X1 += i;
				count_1++;
			}
		}
	
		if (count_1 == 0)
		{
			x1 = 160;
		}
		else
		{
			pos_X1 /= count_1;
	
			x1 = pos_X1;	
		}
	}
	else
	{
		x1 = pre_x1;
	}

	if(count_Clst2 > 1)
	{
		for (int i = 0; i < fr_Input__Width; i++)
		{
			if (array_2[i] != 0)
			{
				pos_X2 += i;
				count_2++;
			}
		}

		if (count_2 == 0)
		{
			x2 = 160;
		}
		else
		{
			pos_X2 /= count_2;
	
			x2 = pos_X2;	
		}
	}
	else
	{
		x2 = pre_x2;
	}

	pre_x1 = x1;
	pre_x2 = x2;

	y1 = thres_PosY_1;
	y2 = thres_PosY_2;

	frame_OUT->imageData[(y1 - 1) * frame_IN->widthStep + x1 * frame_IN->nChannels + 2] = 0xFF;
	frame_OUT->imageData[(y1 + 1) * frame_IN->widthStep + x1 * frame_IN->nChannels + 2] = 0xFF;
	frame_OUT->imageData[(y1)* frame_IN->widthStep + (x1 - 1) * frame_IN->nChannels + 2] = 0xFF;
	frame_OUT->imageData[(y1)* frame_IN->widthStep + (x1 + 1) * frame_IN->nChannels + 2] = 0xFF;
	frame_OUT->imageData[(y2 - 1) * frame_IN->widthStep + x2 * frame_IN->nChannels + 1] = 0xFF;
	frame_OUT->imageData[(y2 + 1) * frame_IN->widthStep + x2 * frame_IN->nChannels + 1] = 0xFF;
	frame_OUT->imageData[(y2)* frame_IN->widthStep + (x2 - 1) * frame_IN->nChannels + 1] = 0xFF;
	frame_OUT->imageData[(y2)* frame_IN->widthStep + (x2 + 1) * frame_IN->nChannels + 1] = 0xFF;
}

bool waitKey()
{
	return cvWaitKey(33) >= 27;
}
