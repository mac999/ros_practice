int funcMOT_InitUART();
void funcMOT_CloseUART();
void funcMOT_InitializeDXL();
void funcMOT_InitDXLMode();
void funcMOT_InitDXLTorque();
void funcMOT_DisposeDXLTorque();
void funcMOT_InitDXLMove();
void funcMOT_MoveDXL(int pos);//JOINT
void funcMOT_CalcMotion(double &dL, double &dR);//SPEED
void funcMOT_PrintCommStatus(int CommStatus);
void funcMOT_PrintErrorCode(int ErrorCode);

