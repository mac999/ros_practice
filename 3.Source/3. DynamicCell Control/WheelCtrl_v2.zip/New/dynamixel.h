void func_FixDXL__InitializeDXL();
void func_FixDXL__Move(unsigned char spdL_H, unsigned char spdL_L, unsigned char spdR_H, unsigned char spdR_L);
void func_FixDXL__InitializeMode();
void func_FixDXL__InitializeMove();
void func_FixDXL__InitializeTorque();
int func_FixDXL__InitUART();
int func_FixDXL__SendPacket2(unsigned char ucID, unsigned char ucInst, unsigned char ucParamLen,  unsigned char *ucpBuf, const char *cpMsg);
unsigned short update_crc(unsigned short crc_accum, unsigned char *data_blk_ptr, unsigned short data_blk_size);
void func_FixDXL__CloseUART();
