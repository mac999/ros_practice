/////////////////////////////////////////////////////
// A Simple Line Tracking Framework for Two Wheel ver.1.0
// LEON
/////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include <iostream>
#include "motion.h"

using namespace std;

//WheelCtrl sp_L sp_R
//sp_L  범위 -100~100
//sp_R  범위 -100~100

int main(int argc, char* argv[])
{
	// Parameters
	int sp_L=atoi(argv[1]);
	int sp_R=atoi(argv[2]);

	double dL=sp_L;
	double dR=sp_R;


	if(dL==0 && dR==0)
	{
		// Serial Port Initializing
		if (funcMOT_InitUART() == 0)
		{
			printf("ERROR : InitUART\n");
			return 0;
		}
		sleep(1);
		// DXL Initializing
		funcMOT_InitializeDXL();

		// Motion Calculating
		//funcMOT_CalcMotion(dL, dR);

		// DXL Configurating
		//funcMOT_MoveDXL();
		
	}
	else
	{
		// Serial Port Initializing
		if (funcMOT_InitUART() == 0)
		{
			printf("ERROR : InitUART\n");
			return 0;
		}
		//sleep(1);
		// DXL Initializing
		//funcMOT_InitializeDXL();

		// Motion Calculating
		funcMOT_CalcMotion(dL, dR);
		printf("dL=%f dR=%f\n", dL, dR);

		// DXL Configurating
		funcMOT_MoveDXL();
	}


	return 0;
}



